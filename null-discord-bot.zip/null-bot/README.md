# null — Discord tickets, applications, and vouches

Node.js 20.11+ bot for one Discord server. The bot's **display name** is set to `null` in the Discord Developer Portal; the code itself cannot rename the application. All records are stored in `data/state.json` by default. Keep that file on persistent storage and back it up.

## Features

- `/ticket open`: private channel for the member and staff. `/ticket close` locks the owner out of sending; staff can `/ticket reopen` or `/ticket delete`. Ticket owners and staff can `/ticket add` and `/ticket remove` other members.
- `/apply`: three-question application form. Staff receive Approve and Reject buttons in a private review channel; applicants receive a DM if permitted. A member can reapply after a decision.
- `/vouch user reason`: posts a public recommendation. Each member may vouch once per person, cannot vouch for themself or a bot, and the recipient must belong to the server. `/vouches user` shows the total and five recent reasons.
- `/panel type:tickets` or `/panel type:applications`: posts a reusable button panel in the current channel.

## Install

1. Create an application at [Discord Developer Portal](https://discord.com/developers/applications), name it **null**, and add a Bot user. Copy its **bot token** and **application ID**. Never share the token.
2. Under Installation, enable **Guild Install** with scopes `bot` and `applications.commands`. Grant the bot **View Channels**, **Send Messages**, **Embed Links**, **Read Message History**, and **Manage Channels**. Install it in your server. The person installing it needs Manage Server permission.
3. In Discord settings, enable Developer Mode; right-click your server and copy its ID.
4. Copy `.env.example` to `.env`, enter `DISCORD_TOKEN`, `CLIENT_ID`, and `GUILD_ID`. Optionally set `DATA_FILE` to a path on your host's persistent disk.
5. Run:

   ```bash
   npm install
   npm run deploy
   npm start
   ```

   `npm run deploy` registers the slash commands for the configured server. Re-run it when command definitions change. Keep `npm start` running on an always-on host.

6. Create a staff role, a tickets **category**, a private staff-only **applications** text channel, and a public **vouches** text channel. Ensure the bot can read and send messages in both text channels. Run `/setup` and select those resources. **Check that ordinary members cannot view the applications channel.** You can optionally select a logs channel.
7. Post `/panel type:tickets` and `/panel type:applications` in the channels where members should see them. Members can also use `/ticket open` and `/apply` directly.

## Operational notes

The bot uses only the Guilds gateway intent; Message Content and Server Members privileged intents are not needed. It must retain its channel permissions, and the staff role must retain access to the ticket category. Closed ticket channels stay available to staff until deleted; there is no transcript export. `/ticket delete` permanently removes the Discord channel. Application submissions and vouches are not automatically moderated. For a single running instance, local JSON storage is sufficient; do not run two copies against the same data file. For hosted deployment, configure a persistent volume for `DATA_FILE`.

To change application questions, edit `applicationModal()` and the matching field reads in `src/index.js`, then restart the bot. To change slash command definitions, edit `src/commands.js` and rerun `npm run deploy`.
